package com.way.exception;

public class XXAdressMalformedException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public XXAdressMalformedException(String msg) {
		super(msg);
	}

}